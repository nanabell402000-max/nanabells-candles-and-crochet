Deploy to Vercel → New Project → upload zip. Add ENV VARS, then publish. Images are in /public/gallery.
