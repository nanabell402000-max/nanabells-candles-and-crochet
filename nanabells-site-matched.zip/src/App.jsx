
import React, { useEffect, useRef, useState } from "react";
import emailjs from "@emailjs/browser";

export default function App() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [sentMsg, setSentMsg] = useState("");

  const brand = {
    name: "Nanabell's Candles and Crochet",
    tagline: "Hand-poured scents & heirloom crochet pieces",
    email: "nanabell402000@yahoo.com",
    instagram: "https://instagram.com/crochetallday",
    etsy: "",
    ravelry: "https://www.ravelry.com/advertisers/nanabellscrochetcreations/ads/active",
    location: "Nashville, TN",
    paypalClientId: import.meta.env.VITE_PAYPAL_CLIENT_ID || "ARfjlizKcIsDNHT5dBgHL...",
    emailjsServiceId: import.meta.env.VITE_EMAILJS_SERVICE_ID || "YOUR_EMAILJS_SERVICE_ID",
    emailjsTemplateId: import.meta.env.VITE_EMAILJS_ORDER_TEMPLATE_ID || "YOUR_EMAILJS_ORDER_TEMPLATE_ID",
    emailjsPublicKey: import.meta.env.VITE_EMAILJS_PUBLIC_KEY || "YOUR_EMAILJS_PUBLIC_KEY",
    instagramWidgetUrl: "https://snapwidget.com/embed/your-widget-id",
  };

  const candles = [
    { id: "candle-sleigh-ride", name: "Sleigh Ride", price: "$12", priceNumber: 12, size: "8 oz soy blend", desc: "Crisp winter air with subtle pine and spice.", img: "/gallery/sleigh-ride-a.jpg" },
    { id: "candle-fruity-rings", name: "Fruity Rings", price: "$12", priceNumber: 12, size: "8 oz soy blend", desc: "Bright, sweet, cereal nostalgia.", img: "https://placehold.co/600x480/png?text=Fruity+Rings" },
    { id: "candle-tobacco-caramel", name: "Tobacco Caramel", price: "$12", priceNumber: 12, size: "8 oz soy blend", desc: "Warm pipe tobacco with rich caramel.", img: "https://placehold.co/600x480/png?text=Tobacco+Caramel" },
    { id: "candle-sweet-grace", name: "Sweet Grace", price: "$12", priceNumber: 12, size: "8 oz soy blend", desc: "Soft florals and clean musk.", img: "https://placehold.co/600x480/png?text=Sweet+Grace" },
    { id: "candle-japanese-cherry", name: "Japanese Cherry Blossom", price: "$12", priceNumber: 12, size: "8 oz soy blend", desc: "Delicate cherry blossom, powdery finish.", img: "/gallery/japanese-cherry-blossom.jpg" },
    { id: "candle-coffee", name: "Fresh Brewed Coffee", price: "$12", priceNumber: 12, size: "8 oz soy blend", desc: "Strong, bold, freshly brewed aroma.", img: "/gallery/fresh-brewed-coffee.jpg" },
    { id: "candle-baja", name: "Baja Cactus Blossom", price: "$12", priceNumber: 12, size: "8 oz soy blend", desc: "Cactus flower with coconut and amber.", img: "https://placehold.co/600x480/png?text=Baja+Cactus+Blossom" },
    { id: "candle-dior-sauvage", name: "Dior Sauvage", price: "$12", priceNumber: 12, size: "8 oz soy blend", desc: "Bold, masculine scent inspired by the icon.", img: "https://placehold.co/600x480/png?text=Dior+Sauvage" },
    { id: "candle-butt-naked", name: "Butt Naked", price: "$12", priceNumber: 12, size: "8 oz soy blend", desc: "Playful tropical fruits and vanilla.", img: "https://placehold.co/600x480/png?text=Butt+Naked" },
    { id: "candle-apple-cider-snickerdoodle", name: "Apple Cider Snickerdoodle", price: "$12", priceNumber: 12, size: "8 oz soy blend", desc: "Warm cinnamon sugar + crisp cider.", img: "/gallery/apple-cider-snickerdoodle.jpg" },
    { id: "candle-maple-chai-cream", name: "Maple Chai Cream", price: "$12", priceNumber: 12, size: "8 oz soy blend", desc: "Creamy maple and cozy chai spices.", img: "/gallery/maple-chai-cream.jpg" },
    { id: "candle-slot-12", name: "Coming Soon", price: "$12", priceNumber: 12, size: "8 oz soy blend", desc: "Your next scent here.", img: "/gallery/sleigh-ride-b.jpg" }
  ];

  const crochet = [
    { id: "crochet-bucket-cloche", name: "Bucket Cloche Hat", price: "$10", priceNumber: 10, sizes: "Infant–Adult", desc: "Choose from beanie, cloche, bucket, fun, ruffle and various other hat styles, each one unique.", img: "/gallery/hat-placeholder.jpg" },
    { id: "crochet-football-beanie", name: "Football Beanie", price: "$10", priceNumber: 10, sizes: "0–3 mo to Child", desc: "Choose from beanie, cloche, bucket, fun, ruffle and various other hat styles, each one unique.", img: "/gallery/hat-placeholder.jpg" },
    ...Array.from({length:10}, (_,i)=>({ id: `crochet-slot-${i+3}`, name: "Hat Style", price: "$10", priceNumber: 10, sizes: "Infant–Adult", desc: "Add photo and name.", img: "/gallery/hat-placeholder.jpg" }))
  ];

  const paypalLoadedRef = useRef(false);
  useEffect(() => {
    if (paypalLoadedRef.current) return;
    const id = brand.paypalClientId;
    if (!id || id.includes("...")) return;
    const script = document.createElement("script");
    script.src = `https://www.paypal.com/sdk/js?client-id=${id}&currency=USD&intent=capture`;
    script.async = true;
    script.onload = () => { paypalLoadedRef.current = true; };
    document.body.appendChild(script);
  }, [brand.paypalClientId]);

  function PayPalButton({ item }) {
    const btnRef = useRef(null);
    useEffect(() => {
      let isMounted = true;
      const iv = setInterval(() => {
        if (window.paypal && btnRef.current && isMounted) {
          clearInterval(iv);
          btnRef.current.innerHTML = "";
          window.paypal.Buttons({
            style: { layout: "vertical", shape: "pill", label: "paypal" },
            createOrder: (data, actions) => actions.order.create({
              purchase_units: [{ reference_id: item.id, description: item.name, amount: { currency_code: "USD", value: item.priceNumber.toFixed(2) } }],
            }),
            onApprove: async (data, actions) => {
              const details = await actions.order.capture();
              alert(`Thank you! Payment received for ${item.name}. Order: ${details.id}`);
            },
            onError: (err) => { console.error(err); alert("PayPal error — try again or contact us."); },
          }).render(btnRef.current);
        }
      }, 200);
      return () => { isMounted = false; clearInterval(iv); };
    }, [item.id, item.name, item.priceNumber]);
    return <div className="mt-3" ref={btnRef} />;
  }

  const formRef = useRef(null);
  async function handleSubmit(e) {
    e.preventDefault();
    if (!brand.emailjsServiceId || !brand.emailjsTemplateId || !brand.emailjsPublicKey ||
        brand.emailjsServiceId.includes("YOUR_")) {
      alert("Email service not configured yet. Add EmailJS IDs in Vercel → Settings → Environment Variables.");
      return;
    }
    const formData = new FormData(formRef.current);
    try {
      setSending(true); setSentMsg("");
      await emailjs.send(brand.emailjsServiceId, brand.emailjsTemplateId, {
        from_name: formData.get("name"), reply_to: formData.get("contact"),
        order_type: formData.get("type"), message: formData.get("details"), to_email: brand.email,
      }, { publicKey: brand.emailjsPublicKey });
      setSentMsg("Thanks! Your request was sent. We also emailed you a confirmation.");
      formRef.current.reset();
    } catch (err) {
      console.error(err); setSentMsg("We couldn't send your message. Please email us directly.");
    } finally { setSending(false); }
  }

  const galleryImages = [
    { src: "/gallery/hawaiian-pink-hibiscus.jpg", alt: "hawaiian pink hibiscus" },
    { src: "/gallery/apple-cider-snickerdoodle.jpg", alt: "apple cider snickerdoodle" },
    { src: "/gallery/sleigh-ride-a.jpg", alt: "sleigh ride" },
    { src: "/gallery/sleigh-ride-b.jpg", alt: "sleigh ride" },
    { src: "/gallery/maple-chai-cream.jpg", alt: "maple chai cream" },
    { src: "/gallery/pumpkin-cheesecake.jpg", alt: "pumpkin cheesecake" },
    { src: "/gallery/fresh-brewed-coffee.jpg", alt: "fresh brewed coffee" },
    { src: "/gallery/japanese-cherry-blossom.jpg", alt: "japanese cherry blossom" },
  ];
  while (galleryImages.length < 24) {
    galleryImages.push({ src: "https://placehold.co/600x600/png?text=Photo", alt: "Photo" });
  }

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900">
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur border-b border-neutral-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <a href="#home" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-neutral-900 text-white grid place-items-center font-bold">NS</div>
            <div className="leading-tight">
              <div className="font-extrabold tracking-tight text-lg">{brand.name}</div>
              <div className="text-xs text-neutral-500 -mt-0.5">{brand.tagline}</div>
            </div>
          </a>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a className="hover:opacity-70" href="#candles">Candles</a>
            <a className="hover:opacity-70" href="#crochet">Crochet</a>
            <a className="hover:opacity-70" href="#gallery">Gallery</a>
            <a className="hover:opacity-70" href="#instagram">Instagram</a>
            <a className="hover:opacity-70" href="#about">About</a>
            <a className="hover:opacity-70" href="#faq">FAQ</a>
            <a className="hover:opacity-70" href="#contact">Contact</a>
          </nav>
          <button onClick={() => setMobileOpen(!mobileOpen)} className="md:hidden inline-flex items-center gap-2 border rounded-xl px-3 py-2">
            <span className="text-sm">Menu</span>
            <span className={`transition ${mobileOpen ? "rotate-180" : ""}`}>▾</span>
          </button>
        </div>
      </header>

      <section id="home" className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-rose-100 via-white to-amber-100" />
        <div className="max-w-6xl mx-auto px-4 py-16 md:py-24">
          <h1 className="text-4xl md:text-6xl font-black tracking-tight leading-tight">Handmade warmth for your home and heart.</h1>
          <p className="mt-4 text-neutral-700 text-lg">Small-batch candles and heirloom-quality crochet—crafted in {brand.location}.</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a href="#candles" className="px-5 py-3 rounded-2xl bg-neutral-900 text-white font-semibold hover:opacity-90">Shop Candles</a>
            <a href="#crochet" className="px-5 py-3 rounded-2xl border border-neutral-300 font-semibold hover:bg-white">Shop Crochet</a>
            <a href={brand.ravelry} target="_blank" rel="noreferrer" className="px-5 py-3 rounded-2xl border border-neutral-300 font-semibold hover:bg-white">Ravelry Shop</a>
          </div>
        </div>
      </section>

      <section id="candles" className="py-12 md:py-20 border-t border-neutral-200 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight">Candles ($12)</h2>
          <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {candles.map((c) => (
              <div key={c.id} className="rounded-3xl border border-neutral-200 p-5 bg-neutral-50 hover:bg-white hover:shadow-md transition">
                <img src={c.img} alt={c.name} className="w-full h-40 object-cover rounded-2xl mb-3" />
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-bold text-lg tracking-tight">{c.name}</h3>
                  <div className="font-bold">{c.price}</div>
                </div>
                <div className="text-xs text-neutral-500 mt-1">{c.size}</div>
                <p className="text-sm text-neutral-700 mt-1">{c.desc}</p>
                {c.badge && (<div className="inline-block mt-3 text-xs bg-amber-100 text-amber-900 px-2 py-1 rounded-xl">{c.badge}</div>)}
                <PayPalButton item={c} />
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="crochet" className="py-12 md:py-20 bg-neutral-50 border-t border-neutral-200">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight">Crochet Hats ($10)</h2>
          <p className="text-neutral-700 mt-2">Ready-made crochet pieces.</p>
          <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {crochet.map((p) => (
              <div key={p.id} className="rounded-3xl border border-neutral-200 bg-white p-5">
                <img src={p.img} alt={p.name} className="w-full h-40 object-cover rounded-2xl mb-3" />
                <div className="font-bold text-lg">{p.name}</div>
                <div className="text-neutral-700 text-sm">{p.sizes}</div>
                <div className="mt-1 font-semibold">{p.price}</div>
                <p className="text-sm text-neutral-600 mt-1">{p.desc}</p>
                <PayPalButton item={p} />
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="gallery" className="py-12 md:py-20 bg-white border-t border-neutral-200">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight">Gallery</h2>
          <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-3">
            {galleryImages.map((g, i) => (
              <div key={i} className="aspect-square rounded-2xl border border-neutral-200 bg-neutral-50 overflow-hidden">
                <img src={g.src} alt={g.alt} loading="lazy" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="instagram" className="py-12 md:py-20 bg-neutral-50 border-t border-neutral-200">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight">Instagram</h2>
          <div className="mt-6 rounded-3xl overflow-hidden border border-neutral-200 bg-white">
            <iframe title="Instagram Feed" src={brand.instagramWidgetUrl} className="w-full h-[500px]" loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
          </div>
          <div className="mt-3 text-sm">
            <a className="underline" href={brand.instagram} target="_blank" rel="noreferrer">@ crochetallday</a>
          </div>
        </div>
      </section>

      <section id="about" className="py-12 md:py-20 bg-white border-t border-neutral-200">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight">About</h2>
          <p className="mt-4 text-neutral-700">We craft small-batch candles and crochet pieces with timeless style and everyday practicality. Every order is poured or stitched by hand in {brand.location}.</p>
          <ul className="mt-4 space-y-2 text-neutral-800">
            <li>• Clean ingredients and quality fibers</li>
            <li>• Thoughtful packaging, gift-ready</li>
            <li>• Custom requests welcome</li>
          </ul>
        </div>
      </section>

      <section id="faq" className="py-12 md:py-20 bg-neutral-50 border-t border-neutral-200">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight">FAQ</h2>
          <div className="mt-8 grid md:grid-cols-2 gap-5">
            {[
              { q: "What wax do you use?", a: "Natural soy blend with cotton wicks for a clean burn." },
              { q: "Custom orders?", a: "Yes—candles (labels/scents) and crochet (sizes/colors). Use the form below." },
              { q: "Processing times", a: "Ready-to-ship: 2–3 days. Made-to-order: 1–2 weeks depending on queue." },
              { q: "Local pickup?", a: "Yes in Nashville by appointment. We also ship USPS." },
            ].map((f, i) => (
              <div key={i} className="rounded-3xl border border-neutral-200 p-5 bg-white">
                <div className="font-semibold">{f.q}</div>
                <p className="text-sm text-neutral-700 mt-1">{f.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="py-12 md:py-20 bg-white border-t border-neutral-200">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight">Contact & Custom Orders</h2>
          <form ref={formRef} onSubmit={handleSubmit} className="mt-8 grid md:grid-cols-2 gap-5">
            <input name="name" className="w-full rounded-2xl border border-neutral-300 px-4 py-3" placeholder="Your Name" required />
            <input name="contact" className="w-full rounded-2xl border border-neutral-300 px-4 py-3" placeholder="Email or Phone" required />
            <input name="type" className="w-full rounded-2xl border border-neutral-300 px-4 py-3 md:col-span-2" placeholder="Order Type (candle scent / crochet item)" />
            <textarea name="details" className="w-full rounded-2xl border border-neutral-300 px-4 py-3 md:col-span-2" placeholder="Details (quantities, sizes, color palette, timeline)"></textarea>
            <div className="md:col-span-2 flex gap-3 items-center">
              <button disabled={sending} className="px-5 py-3 rounded-2xl bg-neutral-900 text-white font-semibold hover:opacity-90 disabled:opacity-60">
                {sending ? "Sending..." : "Send Request"}
              </button>
              <a href={`mailto:${brand.email}`} className="text-sm underline">or email {brand.email}</a>
            </div>
            {sentMsg && <div className="md:col-span-2 text-sm text-emerald-700">{sentMsg}</div>}
          </form>
        </div>
      </section>

      <footer className="py-10 border-t border-neutral-200 bg-neutral-50">
        <div className="max-w-6xl mx-auto px-4 grid sm:grid-cols-2 gap-6 items-center">
          <div className="text-sm text-neutral-600">© {new Date().getFullYear()} {brand.name} — {brand.location}</div>
          <div className="flex gap-4 sm:justify-end text-sm">
            <a href={brand.instagram} className="underline" target="_blank" rel="noreferrer">Instagram</a>
            <a href={brand.ravelry} className="underline" target="_blank" rel="noreferrer">Ravelry</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
